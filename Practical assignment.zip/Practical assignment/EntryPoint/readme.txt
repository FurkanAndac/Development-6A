﻿- Since the latest version of monogame, you must use files .xnb for the graphical assets compile with the Monogame pipeline.
- In order to do so, open the file in Content\Content.mgcb (double click on it, if it does not work, you haven't installed monogame correctly)
- Open the build tab and select build (or press F6).
- Go to Content/bin/Windows